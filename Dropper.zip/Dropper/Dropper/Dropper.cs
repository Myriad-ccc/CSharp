﻿using Dropper.Properties;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Dropper
{
    public partial class Form1 : Form
    {
        private static readonly string customFont = "VCR OSD Mono";

        private static Panel borderBox;
        private static Color TitleColor = QOL.RandomColor();
        private static Color ShadowTitleColor = QOL.RandomColor();

        private static readonly bool showScale = false;

        private static CustomPanel area;
        private static CustomPanel toolBar;
        private static CustomPanel floor;

        private static readonly Block block = new Block(RectangleF.Empty, 10);
        private static Point startPoint;
        private static Timer gravityTimer;

        private ClickFilter weightDisplayFilter;

        public Form1() => InitializeComponent();

        private void Form1_Load(object sender, EventArgs e)
        {
            ConfigureForm();
            SetScene();
            BlockPhysics();
            ToolBar();
        }

        private void ConfigureForm()
        {
            Text = "Dropper";
            FormBorderStyle = FormBorderStyle.None;
            Size = new Size(1024, 896);
            BackColor = Color.FromArgb(255, 20, 20, 20);
            KeyPreview = true;
            DoubleBuffered = true;
            FormClosing += Form1_Closing;
            BorderMenu();
            CenterToScreen();
        }

        private void Form1_Closing(object sender, EventArgs e)
        {
            if (weightDisplayFilter != null)
                Application.RemoveMessageFilter(weightDisplayFilter);
        }

        private void BorderMenu()
        {
            borderBox = new Panel()
            {
                Location = new Point(0, 0),
                Size = new Size(Width, 64)
            };
            Controls.Add(borderBox);


            Button closingButton = new Button()
            {
                Size = new Size(56, 56),
                ForeColor = Color.FromArgb(255, 163, 42, 42),
                Font = new Font(customFont, 20f),
                TextAlign = ContentAlignment.MiddleCenter,
                Text = "✖",
                TabStop = false,
                FlatStyle = FlatStyle.Flat,
            };
            closingButton.Location = new Point(Width - 4 - closingButton.Width, 4);
            closingButton.MouseClick += (s, ev) => Close();
            borderBox.Controls.Add(closingButton);


            int gap = 16;


            Button minimizeButton = new Button()
            {
                Size = new Size(56, 56),
                ForeColor = Color.FromArgb(255, 42, 163, 150),
                Font = new Font(customFont, 20f),
                TextAlign = ContentAlignment.MiddleCenter,
                Text = "―",
                TabStop = false,
                FlatStyle = FlatStyle.Flat,
            };
            minimizeButton.Location = new Point(closingButton.Left - gap - minimizeButton.Width, 4);
            minimizeButton.MouseClick += (s, ev) => WindowState = FormWindowState.Minimized;
            borderBox.Controls.Add(minimizeButton);


            borderBox.Paint += (s, ev) =>
            {
                Graphics g = ev.Graphics;

                using (SolidBrush borderPen = new SolidBrush(Color.FromArgb(255, 35, 35, 35)))
                    g.FillRectangle(borderPen, borderBox.ClientRectangle);

                using (var shadowBrush = new SolidBrush(TitleColor))
                using (var mainBrush = new SolidBrush(ShadowTitleColor))
                using (var font = new Font(customFont, 32f))
                {
                    g.DrawString(Text, font, shadowBrush, new Point(10, 10));
                    g.DrawString(Text, font, mainBrush, new Point(9, 9));
                }
            };
            DragControl(borderBox, true);
        }

        public static void DragControl(Control control, bool parent)
        {
            var target = parent ? control.Parent : control;

            bool dragging = false;
            Point cursorPos = Cursor.Position;

            control.MouseDown += (s, ev) =>
            {
                if (ev.Button == MouseButtons.Left)
                {
                    dragging = true;
                    cursorPos = Cursor.Position;
                }
                if (ev.Button == MouseButtons.Right && !dragging)
                {
                    TitleColor = QOL.RandomColor();
                    ShadowTitleColor = QOL.RandomColor();
                    control.Invalidate();
                }
            };

            control.MouseUp += (s, ev) => dragging = false;

            control.MouseMove += (s, ev) =>
            {
                if (dragging)
                {
                    int deltaX = Cursor.Position.X - cursorPos.X;
                    int deltaY = Cursor.Position.Y - cursorPos.Y;

                    target.Left += deltaX;
                    target.Top += deltaY;

                    cursorPos = Cursor.Position;

                    if (parent)
                        target.Invalidate();
                    else
                        target.Parent.Invalidate();
                }
            };
        }

        private void SetScene()
        {
            area = new CustomPanel();
            area.Location = new Point(0, borderBox.Bottom);
            area.Size = new Size(ClientSize.Width, ClientSize.Height - borderBox.Height);
            area.Paint += Area_Paint;
            Controls.Add(area);

            toolBar = new CustomPanel();
            toolBar.Location = new Point(0, 0);
            toolBar.Size = new Size(area.Width, 96);
            toolBar.Paint += (s, ev) =>
            {
                var g = ev.Graphics;
                using (var toolBarBrush = new SolidBrush(Color.FromArgb(255, 50, 50, 50)))
                    g.FillRectangle(toolBarBrush, toolBar.ClientRectangle);

            };
            area.Controls.Add(toolBar);

            floor = new CustomPanel();
            floor.Location = new Point(0, area.Height - 32);
            floor.Size = new Size(area.Width, 32);
            floor.Paint += (s, ev) =>
            {
                var g = ev.Graphics;
                using (var floorBrush = new SolidBrush(Color.FromArgb(255, 40, 40, 40)))
                    g.FillRectangle(floorBrush, floor.ClientRectangle);

            };
            area.Controls.Add(floor);

            startPoint = new Point((int)(floor.Width / 2 - block.W / 2), (int)(floor.Top - block.H));
            block.Bounds = new RectangleF(startPoint, block.Size);
        }

        private void Area_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            if (block.Bounds.Location == Point.Empty)
                g.FillRectangle(Brushes.ForestGreen, new Rectangle(startPoint, new Size((int)block.W, (int)block.H)));
            else
            {
                //Point blockPos = block.Bounds.Location;
                using (var blockBrush = new SolidBrush((Color)block.Color))
                    g.FillRectangle(blockBrush, block.Bounds);
                using (var borderPen = new Pen((Color)block.BorderColor, (float)block.BorderWidth))
                    g.DrawRectangle(borderPen, block.Bounds.X, block.Bounds.Y, block.Bounds.Width, block.Bounds.Height);
            }

            if (showScale)
            {
                Bitmap scale = Resources.myscale;
                g.DrawImage(scale, new Point(Width - scale.Width, toolBar.Bottom));
            }
        }

        private void BlockPhysics()
        {
            DragBlock(block, area);
            CheckGravity(block);
        }

        public void DragBlock(Block block, Control parent)
        {
            block.Dragging = false;
            PointF cursorPos = Cursor.Position;

            parent.MouseDown += (s, ev) =>
            {
                if (ev.Button == MouseButtons.Left && block.Bounds.Contains(ev.Location))
                {
                    block.Dragging = true;
                    cursorPos = Cursor.Position;
                }
            };

            parent.MouseUp += (s, ev) => block.Dragging = false;

            parent.MouseMove += (s, ev) =>
            {
                if (block.Dragging)
                {
                    float deltaX = Cursor.Position.X - cursorPos.X;
                    float deltaY = Cursor.Position.Y - cursorPos.Y;

                    block.Bounds = new RectangleF(
                        new PointF(
                            block.X + deltaX,
                            block.Y + deltaY),
                        block.Bounds.Size);

                    cursorPos = Cursor.Position;
                    ConstrainToArea(block, parent);
                    parent.Invalidate();
                }
            };
        }

        private void ConstrainToArea(Block block, Control area)
        {
            float cx = block.X;
            float cy = block.Y;
            float bw = block.BorderWidth;
            float w = block.W;
            float h = block.H;

            if (cx < area.ClientRectangle.Left)
                cx = area.ClientRectangle.Left;

            if (cx + w + bw > area.ClientRectangle.Right)
                cx = area.ClientRectangle.Right - w - bw;

            if (cy < toolBar.Bottom)
                cy = toolBar.Bottom;

            if (cy + h > floor.Top)
                cy = floor.Top - h;

            block.Bounds = new RectangleF(new PointF(cx, cy), block.Size);
        }

        private void CheckGravity(Block block)
        {
            gravityTimer = new Timer() { Interval = 8 };
            gravityTimer.Tick += (s, ev) =>
            {
                if (!block.Dragging)
                {
                    ApplyGravity(block);
                    area.Invalidate();
                }
            };
            gravityTimer.Start();
        }

        private void ApplyGravity(Block block)
        {
            if (block.LateralPull)
                block.Bounds = new RectangleF(new PointF(block.X - block.Weight, block.Y), block.Size);
            else
                block.Bounds = new RectangleF(new PointF(block.X, block.Y + block.Weight), block.Size);
            ConstrainToArea(block, area);
        }

        private void ToolBar()
        {
            var weightOptions = new CustomPanel()
            {
                ForeColor = Color.Transparent,
                BackColor = QOL.Colors.SameRGB(35),
                Width = toolBar.Width,
                Height = 24,
                Location = new Point(toolBar.Left, toolBar.Top)
            };
            toolBar.Controls.Add(weightOptions);
            weightOptions.Paint += (s, ev) =>
            {
                using (var pen = new Pen(BackColor, 1f))
                    ev.Graphics.DrawRectangle(pen, 0, 0, weightOptions.Width - 1, weightOptions.Height - 1);
            };

            var weight = new Label()
            {
                Tag = "ToolBarInfoLabel",
                Anchor = AnchorStyles.Top | AnchorStyles.Left,
                BackColor = Color.Transparent,
                ForeColor = Color.White,
                Font = new Font(customFont, 16f),
                Text = "Weight:",
                Height = weightOptions.Height,
            };
            weightOptions.Controls.Add(weight);

            float originalWeight = block.Weight;
            var weightDisplay = new TextBox()
            {
                Tag = "ToolBarInfoLabel",
                Anchor = AnchorStyles.Left,
                BackColor = QOL.Colors.SameRGB(100),
                ForeColor = Color.White,
                Font = new Font(customFont, 16f),
                Text = $"{block.Weight:F1}",
                Width = weight.Width,
                BorderStyle = BorderStyle.None,
                TabStop = false,
            };
            QOL.Align.Right(weightDisplay, weight, 6);
            weightDisplay.TextChanged += (s, ev) =>
            {
                if (float.TryParse(weightDisplay.Text, out float newWeight))
                    block.Weight = newWeight;
                else block.Weight = originalWeight;
            };
            weightDisplay.LostFocus += (s, ev) =>
            {
                if (string.IsNullOrEmpty(weightDisplay.Text)
                || !float.TryParse(weightDisplay.Text, out _))
                {
                    weightDisplay.Text = originalWeight.ToString("F1");
                    block.Weight = originalWeight;
                }
            };
            weightOptions.Controls.Add(weightDisplay);
            weightDisplayFilter = new ClickFilter(weightDisplay);
            Application.AddMessageFilter(weightDisplayFilter);

            var minusWeight = new Button()
            {
                UseCompatibleTextRendering = true,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.FromArgb(255, 163, 42, 42),
                BackColor = BackColor,
                Font = new Font(customFont, 20f, FontStyle.Regular),
                Text = "-",
                TabStop = false,
                FlatStyle = FlatStyle.Flat,
                Size = new Size(24, 24)
            };
            QOL.Align.Right(minusWeight, weightDisplay, 4);
            weightOptions.Controls.Add(minusWeight);
            minusWeight.MouseClick += (s, ev) =>
            {
                block.Weight = block.Weight - 5 > int.MinValue ? block.Weight - 5 : block.Weight;
                weightDisplay.Text = block.Weight.ToString("F1");
            };

            var plusWeight = new Button()
            {
                UseCompatibleTextRendering = true,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.Green,
                BackColor = BackColor,
                Font = new Font(customFont, 20f, FontStyle.Regular),
                Text = "+",
                TabStop = false,
                FlatStyle = FlatStyle.Flat,
                Size = minusWeight.Size
            };
            QOL.Align.Right(plusWeight, minusWeight, 1);
            weightOptions.Controls.Add(plusWeight);
            plusWeight.MouseClick += (s, ev) =>
            {
                block.Weight = block.Weight + 5 < int.MaxValue ? block.Weight + 5 : block.Weight;
                weightDisplay.Text = block.Weight.ToString("F1");
            };

            var zeroWeight = new Button()
            {
                TextAlign = ContentAlignment.TopCenter,
                ForeColor = Color.Gray,
                BackColor = BackColor,
                Font = new Font(customFont, 13f, FontStyle.Regular),
                Text = "0",
                TabStop = false,
                FlatStyle = FlatStyle.Flat,
                Size = minusWeight.Size
            };
            QOL.Align.Right(zeroWeight, plusWeight, 1);
            weightOptions.Controls.Add(zeroWeight);
            zeroWeight.MouseClick += (s, ev) =>
            {
                block.Weight = 0;
                weightDisplay.Text = block.Weight.ToString("F1");
            };

            var oneWeight = new Button()
            {
                UseCompatibleTextRendering = true,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.Gray,
                BackColor = BackColor,
                Font = new Font(customFont, 20f, FontStyle.Regular),
                Text = "1",
                TabStop = false,
                FlatStyle = FlatStyle.Flat,
                Size = minusWeight.Size
            };
            QOL.Align.Right(oneWeight, zeroWeight, 1);
            weightOptions.Controls.Add(oneWeight);
            oneWeight.MouseClick += (s, ev) =>
            {
                block.Weight = 1;
                weightDisplay.Text = block.Weight.ToString("F1");
            };

            var resetWeight = new Button()
            {
                UseCompatibleTextRendering = true,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.Gray,
                BackColor = BackColor,
                Font = new Font(customFont, 18f, FontStyle.Regular),
                Text = "↻",
                TabStop = false,
                FlatStyle = FlatStyle.Flat,
                Size = minusWeight.Size
            };
            QOL.Align.Right(resetWeight, oneWeight, 1);
            weightOptions.Controls.Add(resetWeight);
            resetWeight.MouseClick += (s, ev) =>
            {
                block.Weight = originalWeight;
                weightDisplay.Text = block.Weight.ToString("F1");
            };

            var absoluteWeight = new Button()
            {
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.LightGoldenrodYellow,
                BackColor = BackColor,
                Font = new Font(customFont, 12f, FontStyle.Regular),
                Text = "Abs",
                TabStop = false,
                FlatStyle = FlatStyle.Flat,
                Size = new Size(48, 24)
            };
            QOL.Align.Right(absoluteWeight, resetWeight, 1);
            weightOptions.Controls.Add(absoluteWeight);
            absoluteWeight.MouseClick += (s, ev) =>
            {
                if (Math.Abs(block.Weight) > int.MinValue && Math.Abs(block.Weight) < int.MaxValue)
                {
                    block.Weight = originalWeight;
                    weightDisplay.Text = block.Weight.ToString("F1");
                }
            };
            weightOptions.Bounds = new Rectangle(weightOptions.Location, new Size(weightOptions.Controls[weightOptions.Controls.Count - 1].Right, weightOptions.Height));


            var gravityOptions = new CustomPanel()
            {
                ForeColor = Color.Transparent,
                BackColor = QOL.Colors.SameRGB(35),
                Width = toolBar.Width,
                Height = 24,
                Location = new Point(toolBar.Left, toolBar.Top + weightOptions.Height + 1)
            };
            toolBar.Controls.Add(gravityOptions);
            gravityOptions.Paint += (s, ev) =>
            {
                using (var pen = new Pen(BackColor, 1f))
                    ev.Graphics.DrawRectangle(pen, 0, 0, gravityOptions.Width - 1, gravityOptions.Height - 1);
            };

            var gravity = new Label()
            {
                Tag = "ToolBarInfoLabel",
                Anchor = AnchorStyles.Top | AnchorStyles.Left,
                BackColor = Color.Transparent,
                ForeColor = Color.White,
                Font = new Font(customFont, 16f),
                Text = $"Gravity:",
                AutoSize = true,
                Height = gravityOptions.Height,
            };
            gravityOptions.Controls.Add(gravity);

            var reorient = new Button()
            {
                UseCompatibleTextRendering = true,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.RoyalBlue,
                BackColor = Color.Transparent,
                Font = new Font(customFont, 20f, FontStyle.Regular),
                Text = "⇅",
                TabStop = false,
                FlatStyle = FlatStyle.Flat,
                Size = new Size(24, 24),
            };
            reorient.MouseClick += (s, ev) =>
            {
                block.LateralPull = !block.LateralPull;
                if (reorient.Text == "⇄")
                    reorient.Text = "⇅";
                else reorient.Text = "⇄";
            };
            QOL.Align.Right(reorient, gravity, 2);
            gravityOptions.Controls.Add(reorient);

            var bounce = new Button()
            {
                UseCompatibleTextRendering = true,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.CadetBlue,
                BackColor = Color.Transparent,
                Font = new Font(customFont, 12f, FontStyle.Regular),
                Text = "B",
                TabStop = false,
                FlatStyle = FlatStyle.Flat,
                Size = new Size(24, 24),
            };
            gravityOptions.Controls.Add(bounce);
            bool bounceBold = false;
            bounce.MouseClick += (s, ev) =>
            {
                bounceBold = !bounceBold;
                if (bounceBold)
                    bounce.Font = new Font(bounce.Font.FontFamily, bounce.Font.Size, FontStyle.Bold | FontStyle.Underline | FontStyle.Italic);
                else
                    bounce.Font = new Font(bounce.Font.FontFamily, bounce.Font.Size, FontStyle.Regular);
            };
            QOL.Align.Right(bounce, reorient, 1);
        }
    }
}
